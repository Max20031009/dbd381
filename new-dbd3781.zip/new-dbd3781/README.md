# DBD3781 E-Commerce NoSQL Project

A Node.js + MongoDB (sharded) backend for managing an e-commerce marketplace.

Run with:
```
npm install
npm start
```