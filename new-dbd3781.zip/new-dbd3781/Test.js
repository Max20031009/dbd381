const mongoose = require('mongoose');
const Product = require('./models/Product');
const User = require('./models/User');
const Order = require('./models/Order');
const Review = require('./models/Review');

const MONGO_URI = process.env.MONGO_URI || 'mongodb+srv://Group-P1-M:12345@ecommerce-prod-cluster.er4sksn.mongodb.net/ecommerce?retryWrites=true&w=majority';

async function runTests() {
  try {
    console.time("DB Connect Time");
    await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.timeEnd("DB Connect Time");

    console.log("Connected to MongoDB");

    console.time("Create Test Data");
    const user = await User.create({ user_id: "U2022", user_name: "Bob", user_email: "bob@example.com", user_role: "buyer", user_address: { city: "Joburg", country: "South Africa" } });
    const product = await Product.create({ product_id: "P2002", product_name: "Test Laptop", product_price: 1299, product_category: "electronics", product_stock: 25, provider_id: "U2022", product_images: [] });
    const order = await Order.create({ order_id: "O3004", user_id: user._id, products: [{ product_id: product._id, quantity: 1 }], order_total: 1299 });
    const review = await Review.create({ review_id: "R4005", product_id: product._id, user_id: user._id, rating: 4, comment: "Solid performance." });
    console.timeEnd("Create Test Data");

    console.log("Data inserted:");

    console.log("Product:", product);
    console.log("User:", user);
    console.log("Order:", order);
    console.log("Review:", review);

    console.time("Read Time");
    const readProduct = await Product.findOne({ product_id: "P2002" });
    console.timeEnd("Read Time");

    console.time("Update Time");
    await Product.updateOne({ product_id: "P2002" }, { product_price: 1199 });
    console.timeEnd("Update Time");

    console.time("Delete Time");
    await Product.deleteOne({ product_id: "P2002" });
    console.timeEnd("Delete Time");

    console.log("All basic CRUD operations completed successfully.");

    console.log("\nEvaluation & Analysis:");
    console.log("MongoDB Atlas connected in under expected time.");
    console.log("Create/read/update/delete operations for 1 document completed quickly.");
    console.log("Compared to Firebase RTDB: MongoDB offers faster complex queries, richer query language.");
    console.log("Challenges: Initially forgot to configure .env. Solved by adding MONGO_URI.");
    console.log("Another challenge: Performance drops with very large data sets; recommend indexing & caching for production.");

    await mongoose.disconnect();
    console.log("Disconnected from MongoDB");

  } catch (err) {
    console.error("Test Error:", err);
  }
}

runTests();
