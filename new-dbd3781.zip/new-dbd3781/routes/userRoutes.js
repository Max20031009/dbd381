const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.post('/add', async (req, res) => {
  const user = new User(req.body);
  await user.save();
  res.send(user);
});

router.get('/:id', async (req, res) => {
  const user = await User.findById(req.params.id);
  res.send(user);
});

router.put('/update/:id', async (req, res) => {
  const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.send(user);
});

router.delete('/delete/:id', async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.send({ message: 'Deleted' });
});

module.exports = router;
