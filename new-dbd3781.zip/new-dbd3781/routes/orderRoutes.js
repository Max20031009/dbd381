const express = require('express');
const router = express.Router();
const Order = require('../models/Order');

router.post('/add', async (req, res) => {
  const order = new Order(req.body);
  await order.save();
  res.send(order);
});

router.get('/:id', async (req, res) => {
  const order = await Order.findById(req.params.id);
  res.send(order);
});

router.put('/update/:id', async (req, res) => {
  const order = await Order.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.send(order);
});

router.delete('/delete/:id', async (req, res) => {
  await Order.findByIdAndDelete(req.params.id);
  res.send({ message: 'Deleted' });
});

module.exports = router;
