const express = require('express');
const router = express.Router();
const Review = require('../models/Review');

router.post('/add', async (req, res) => {
  const review = new Review(req.body);
  await review.save();
  res.send(review);
});

router.get('/:id', async (req, res) => {
  const review = await Review.findById(req.params.id);
  res.send(review);
});

router.put('/update/:id', async (req, res) => {
  const review = await Review.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.send(review);
});

router.delete('/delete/:id', async (req, res) => {
  await Review.findByIdAndDelete(req.params.id);
  res.send({ message: 'Deleted' });
});

module.exports = router;
